/*
 * This is description of predicates from the cyberintell project.
 */
package coglang;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author appiah
 */
public class JGroupDesc {

    private Map<Integer, String> predicates = new HashMap<Integer, String>();
    private Map<Integer, String> causeEffect = new HashMap<Integer, String>();
    private Map<Integer, String> attacks = new HashMap<Integer, String>();
    private Map<Integer, String> startEnds = new HashMap<Integer, String>();
    private Map<Integer, String> hierarchy = new HashMap<Integer, String>();
    private Map<Integer, String> cases = new HashMap<Integer, String>();
    private Map<Integer, String> cemodel = new HashMap<Integer, String>();
    private Map<Integer, String> transit = new HashMap<Integer, String>();
    private Map<Integer, String> animation = new HashMap<Integer, String>();
    private Map<Integer, Map<Integer, String>> stimulation = new HashMap<Integer, Map<Integer, String>>();

    public Map<Integer, String> getAnimation() {
        animation.put(new Integer(1), "1,2,3,4,5,6,7,8,9,10");
        animation.put(new Integer(2), "2,4,6,8,10,1,3,5,7");
        animation.put(new Integer(3), "3,4,5,6,11,9,1");
        animation.put(new Integer(4), "2,4,8,6,1,2,3");
        animation.put(new Integer(5), "3,2,1,6,7,8,9,11");
        animation.put(new Integer(6), "6,7,8,9,1,2,3,4,5");
        animation.put(new Integer(7), "10,11,12,16,1,2,3,4,5,6");
        animation.put(new Integer(8), "22,16,21,4,8,9,10,2,1");
        animation.put(new Integer(9), "12,16,11,14,15,13,16,21,11");
        animation.put(new Integer(10), "12,16,11,14,9,8,7,2,1");
        animation.put(new Integer(11), "12,16,11,3,5,5,6,8,9");
        animation.put(new Integer(12), "22,5,11,4,5,3,6,2,1");
        animation.put(new Integer(13), "22,22,11,1,5,5,8,8,9");
        animation.put(new Integer(14), "20,20,10,11,15,9,18,18,19");
        animation.put(new Integer(15), "12,22,11,10,15,15,1,1,1");
        animation.put(new Integer(16), "12,11,10,9,7,6,18,18,19");
        animation.put(new Integer(17), "13,12,15,15,15,15,16,16,17");
        animation.put(new Integer(18), "19,19,11,10,15,15,18,18,10");
        animation.put(new Integer(19), "2,2,11,11,8,8,9,9,9,9");
        return animation;
    }

    public Map<Integer, String> getAreaGroup() {
        attacks.put(new Integer(1), "");
        attacks.put(new Integer(2), "");
        attacks.put(new Integer(3), "");

        return attacks;
    }

    public Map<Integer, String> getThingGroup() {
        cases.put(new Integer(1), "");
        cases.put(new Integer(2), "");
        cases.put(new Integer(3), "");
        cases.put(new Integer(4), "");
        cases.put(new Integer(5), "");
        cases.put(new Integer(6), "");
        cases.put(new Integer(7), "");
        cases.put(new Integer(8), "");
        cases.put(new Integer(9), "");
        cases.put(new Integer(10), "");
        cases.put(new Integer(11), "");
        return cases;
    }

    public Map<Integer, String> getLocalGroup() {
        causeEffect.put(new Integer(1), "");
        causeEffect.put(new Integer(2), "");
        causeEffect.put(new Integer(3), "");
        causeEffect.put(new Integer(4), "");
        causeEffect.put(new Integer(5), "");
        causeEffect.put(new Integer(6), "");
        causeEffect.put(new Integer(7), "");
        causeEffect.put(new Integer(8), "");
        causeEffect.put(new Integer(9), " ");

        return causeEffect;
    }

    public Map<Integer, String> getGroupAnalysis() {
        cemodel.put(new Integer(1), "");
        cemodel.put(new Integer(2), "");
        cemodel.put(new Integer(3), "");
        cemodel.put(new Integer(4), "");
        cemodel.put(new Integer(5), "");
        cemodel.put(new Integer(6), "");
        cemodel.put(new Integer(7), "");
        cemodel.put(new Integer(8), "");
        cemodel.put(new Integer(9), "");


        return cemodel;
    }

    public Map<Integer, String> getPeopleGroup() {
        hierarchy.put(new Integer(1), "");
        hierarchy.put(new Integer(2), "");
        hierarchy.put(new Integer(3), "");
        hierarchy.put(new Integer(4), "");
        hierarchy.put(new Integer(5), "");
        hierarchy.put(new Integer(6), "");
        hierarchy.put(new Integer(7), "");
        hierarchy.put(new Integer(8), "");
        hierarchy.put(new Integer(9), "");
        hierarchy.put(new Integer(10), "");

        return hierarchy;
    }

    public Map<Integer, String> getSocialGroup() {
        predicates.put(new Integer(1), "");
        predicates.put(new Integer(2), "");
        predicates.put(new Integer(3), "");
        predicates.put(new Integer(4), "");
        predicates.put(new Integer(5), "");
        predicates.put(new Integer(6), "");
        predicates.put(new Integer(7), "");
        predicates.put(new Integer(8), "");
        predicates.put(new Integer(9), "");


        return predicates;
    }

    public Map<Integer, String> getCountryGroup() {

        startEnds.put(new Integer(1), "");
        startEnds.put(new Integer(2), "");
        startEnds.put(new Integer(3), "");
        startEnds.put(new Integer(4), "");
        startEnds.put(new Integer(5), "");
        startEnds.put(new Integer(6), "");
        startEnds.put(new Integer(7), "");
        startEnds.put(new Integer(7), "");
        startEnds.put(new Integer(8), "");
        startEnds.put(new Integer(9), "");
        startEnds.put(new Integer(10), "");

        return startEnds;
    }

    public Map<Integer, Map<Integer, String>> getStimulation() {
        stimulation.put(new Integer(1), getAreaGroup());
        stimulation.put(new Integer(2), getThingGroup());
        stimulation.put(new Integer(3), getLocalGroup());
        stimulation.put(new Integer(4), getGroupAnalysis());
        stimulation.put(new Integer(5), getPeopleGroup());
        stimulation.put(new Integer(6), getSocialGroup());
        stimulation.put(new Integer(7), getCountryGroup());
        stimulation.put(new Integer(8), getRandomGroup());

        return stimulation;
    }

    public Map<Integer, String> getRandomGroup() {
        transit.put(new Integer(1), "");
        transit.put(new Integer(2), "");
        transit.put(new Integer(3), "");
        transit.put(new Integer(4), "");
        transit.put(new Integer(5), "");
        transit.put(new Integer(6), "");
        transit.put(new Integer(7), "");
        transit.put(new Integer(8), "");
        transit.put(new Integer(9), "");
        transit.put(new Integer(10), "");
        transit.put(new Integer(10), "");
        transit.put(new Integer(11), "");
        transit.put(new Integer(12), "");
        transit.put(new Integer(13), "");
        transit.put(new Integer(14), "");
        transit.put(new Integer(15), "");
        transit.put(new Integer(16), "");
        transit.put(new Integer(17), "");
        transit.put(new Integer(18), "");
        transit.put(new Integer(19), "");
        transit.put(new Integer(20), "");
        transit.put(new Integer(21), "");
        transit.put(new Integer(22), "");

        return transit;
    }
}
