/*
 * JSocioAreaCountryGRpView.java
 */
package coglang;

import java.awt.AWTException;
import java.awt.Color;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Shape;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jdesktop.application.Action;
import org.jdesktop.application.ResourceMap;
import org.jdesktop.application.SingleFrameApplication;
import org.jdesktop.application.FrameView;
import org.jdesktop.application.TaskMonitor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import javax.imageio.ImageIO;
import javax.swing.Timer;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import jcybercat.JGroupDesc;

/**
 * The application's main frame.
 */
public class JSocioAreaCountryGRpView extends FrameView {

    private JGroupDesc groupDesc = new JGroupDesc();
    private int nextIndex = 1,  previewIndex,  lastIndex;
    private int actionIndex = 0;
    private Map<Integer, String> ses;
    private int sleepTime = 3000;
    private int seqLimit = 20;
    boolean anim = false, cyberAnim = false;
    private ActionListener fileStimulusListener,  listener,  cyberListener,  stimulaListener,  timerListener;
    private Timer timer,  timerFileStimulu,  timerAction,  timerSequence,  timerCyber,  timerStimula;
    private int catIndex = 1,  chaseIndex = 1,  operationIndex = 1,  symbolIndex = 1,  intelliIndex = 1,  potentialIndex = 1,  humanIndex = 1,  fileIndex = 1,  frameCount = 1,  cyberTime = 1200,  colorIndex = 0,  actionSequence = 0,  sequence = 1,  eventCount = 0,  eventTime = 1000;
    private Map<Integer, String> groupAnaly = new HashMap<Integer, String>();
    private Vector<String> stimulaVect = new Vector<String>();
    private List<String> localStrList,  sociaList,  cuntryList,  peoList,  areList,  thiList,  grpList;
    private int thiStart=134, thinEnd=187, peoStart=174, peoEnd=184, grpStart= 192, grpEnd=244, coutryStart=0, countryEnd=38, tabIndex = 0,  backIndex = 0, areaStart=41, areaEnd=63, localStart=122, localEnd=172, socioStart=66, socioEnd=120;
    private Color[] backColors = {Color.BLACK,new Color(20,44,55, 190),new Color(120,144,105, 200) ,new  Color(0,0,55, 111), Color.CYAN, Color.DARK_GRAY, Color.GREEN, Color.MAGENTA, Color.ORANGE, Color.getHSBColor(0.1f, 0.2f, 0.4f), Color.getHSBColor(0.18f, 0.4567002f, 0.612774f), Color.getHSBColor(0.771f, 0.66f, 0.664f), Color.getHSBColor(0.81f, 0.62f, 0.94f)};

    public JSocioAreaCountryGRpView(SingleFrameApplication app) {
        super(app);

        initComponents();
        this.getFrame().setIconImage(new ImageIcon(this.getClass().getResource("/coglang/resources/iconapp.png")).getImage());
        // status bar initialization - message timeout, idle icon and busy animation, etc
        ResourceMap resourceMap = getResourceMap();
        int messageTimeout = resourceMap.getInteger("StatusBar.messageTimeout");
        messageTimer = new Timer(messageTimeout, new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                statusMessageLabel.setText("");
            }
        });
        messageTimer.setRepeats(false);
        int busyAnimationRate = resourceMap.getInteger("StatusBar.busyAnimationRate");
        for (int i = 0; i < busyIcons.length; i++) {
            busyIcons[i] = resourceMap.getIcon("StatusBar.busyIcons[" + i + "]");
        }
        busyIconTimer = new Timer(busyAnimationRate, new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                busyIconIndex = (busyIconIndex + 1) % busyIcons.length;
                statusAnimationLabel.setIcon(busyIcons[busyIconIndex]);
            }
        });
        idleIcon = resourceMap.getIcon("StatusBar.idleIcon");
        statusAnimationLabel.setIcon(idleIcon);
        progressBar.setVisible(false);

        // connecting action tasks to status bar via TaskMonitor
        TaskMonitor taskMonitor = new TaskMonitor(getApplication().getContext());
        taskMonitor.addPropertyChangeListener(new java.beans.PropertyChangeListener() {

            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                String propertyName = evt.getPropertyName();
                if ("started".equals(propertyName)) {
                    if (!busyIconTimer.isRunning()) {
                        statusAnimationLabel.setIcon(busyIcons[0]);
                        busyIconIndex = 0;
                        busyIconTimer.start();
                    }
                    progressBar.setVisible(true);
                    progressBar.setIndeterminate(true);
                } else if ("done".equals(propertyName)) {
                    busyIconTimer.stop();
                    statusAnimationLabel.setIcon(idleIcon);
                    progressBar.setVisible(false);
                    progressBar.setValue(0);
                } else if ("message".equals(propertyName)) {
                    String text = (String) (evt.getNewValue());
                 //   statusMessageLabel.setText((text == null) ? "" : text);
                    messageTimer.restart();
                } else if ("progress".equals(propertyName)) {
                    int value = (Integer) (evt.getNewValue());
                    progressBar.setVisible(true);
                    progressBar.setIndeterminate(false);
                    progressBar.setValue(value);
                }
            }
        });

        readStimulations();
        messageTimer.start();
        busyIconTimer.start();

        fileStimulusListener = new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                fileIndex++;
                if (fileIndex > stimulaVect.size() - 1) {
                    fileIndex = 0;
                }
                tabIndex++;
                if (tabIndex > 8) {
                    tabIndex = 0;
                }
                jTabbedPane1.setSelectedIndex(tabIndex);

                stimulusList.setSelectedValue(stimulaVect.get(fileIndex), true);
                catIndex++;
                if (catIndex > localStrList.size() - 1) {
                    catIndex = 0;
                }
                localList.setSelectedValue(localStrList.get(catIndex), true);
                localList.setToolTipText(localStrList.get(catIndex));

                chaseIndex++;
                if (chaseIndex > areList.size() - 1) {
                    chaseIndex = 0;
                }
                areaList.setSelectedValue(areList.get(chaseIndex), true);
                areaList.setToolTipText(areList.get(chaseIndex));

                humanIndex++;
                if (humanIndex > cuntryList.size() - 1) {
                    humanIndex = 0;
                }
                countryList.setSelectedValue(cuntryList.get(humanIndex), true);
                countryList.setToolTipText(cuntryList.get(humanIndex));

                symbolIndex++;
                if (symbolIndex > peoList.size() - 1) {
                    symbolIndex = 0;
                }
                peopleList.setSelectedValue(peoList.get(symbolIndex), true);
                peopleList.setToolTipText(peoList.get(symbolIndex));

                potentialIndex++;
                if (potentialIndex > sociaList.size() - 1) {
                    potentialIndex = 0;
                }
                socialList.setSelectedValue(sociaList.get(potentialIndex), true);
                socialList.setToolTipText(sociaList.get(potentialIndex));
                operationIndex++;
                if (operationIndex > grpList.size() - 1) {
                    operationIndex = 0;
                }
               String[] stimuliColor = {"#FBDBEB", "black", "pink", "white", "#83DCBC", "#9BCFD", "#77CCBC", "#00FFFF", "yellow"};
               
                groupList.setSelectedValue(grpList.get(operationIndex), true);
                groupList.setToolTipText(grpList.get(operationIndex));
                analysisView.setText("<html> <left> <strong> <font size=12 style=bold color=" + stimuliColor[colorIndex] + ">" + new String("Analysis:["+operationIndex + "]:=" + grpList.get(operationIndex)));
              
                intelliIndex++;
                if (intelliIndex > thiList.size() - 1) {
                    intelliIndex = 0;
                }
                thingList.setSelectedValue(thiList.get(intelliIndex), true);
                thingList.setToolTipText(thiList.get(intelliIndex));
                stimulusView.setText("<html> <left> <strong> <font size=14 style=bold color=" + stimuliColor[colorIndex] + ">" + new String(fileIndex + " :=" + stimulaVect.get(fileIndex)));
              
                if (colorIndex > 8) {
                    colorIndex = 0;
                }
                predicateView.setBackground(backColors[colorIndex]);
                stimulusView.setBackground(backColors[colorIndex + 1]);
                textPane.setBackground(backColors[colorIndex + 2]);
                analysisView.setBackground(backColors[colorIndex + 3]);
                
            }
        };
        timerFileStimulu = new Timer(sleepTime, fileStimulusListener);
        timerFileStimulu.setRepeats(true);
        timerFileStimulu.start();
        if (!timerFileStimulu.isRunning()) {
            timerFileStimulu.restart();
        }
        timerSequence = new Timer(30000, timerListener = new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                sequence++;
                if (sequence >= seqLimit) {
                    sequence = 1;
                }
                actionSequence++;
                if (actionSequence > 8) {
                    actionSequence = 0;
                }
                fileIndex++;
                frameCount = 1;
                statusText.setText(statusText.getText() + "\nTimer Sequence=" + sequence + " Action Sequence=" + actionSequence);
                statusText.setText(statusText.getText() + "\nFrame Count=" + frameCount + " File Indexing=" + fileIndex);
            }
        });
        timerSequence.start();

        stimulaListener = new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                Map p = new HashMap();
                p.put(new Integer(1), "120, 6, 2, 2, 11, 1, 129, 20");
                p.put(new Integer(2), "124, 16, 12, 12, 11, 111, 129, 120");
                p.put(new Integer(3), "80, 60, 20, 20, 101, 10, 129, 100");
                p.put(new Integer(4), "84, 86, 72, 21, 116, 112, 129, 120");
                p.put(new Integer(5), "64, 60, 28, 12, 112, 111, 109, 100");
                p.put(new Integer(6), "78, 160, 128, 112, 102, 90, 93, 60");
                p.put(new Integer(7), "64, 60, 28, 12, 112, 111, 109, 70");
                p.put(new Integer(8), "69, 65, 88, 92, 62, 33, 45, 80");
                p.put(new Integer(9), "77, 22, 11, 55, 99, 33, 45, 80");

                String[] stimuliColor = {"#FBCBEB", "pink", "black", "yellow", "#23CCBB", "#9BFFD", "#77CCBC", "#00FFFF", "white"};
                textPane.setText("<html> <left> <strong> <font size=9 color=" + stimuliColor[colorIndex] + ">" + new String(eventCount + " :=" + groupAnaly.get(new Integer(eventCount))));
                // actionList.setSelectedIndex(actionSequence);
                eventCount++;
                colorIndex++;

                //  anim = true;
                if (eventCount >= groupAnaly.size() + 1) {
                    eventCount = 1;
                }
                if (colorIndex >= 9) {
                    colorIndex = 0;
                }

                statusText.setText(statusText.getText() + "\nTimer Sequence=" + sequence + " Action Sequence=" + actionSequence);
                statusText.setText(statusText.getText() + "\nColor Indexing=" + colorIndex + "|| Event Count=" + eventCount);
            }
        };

        timerStimula = new Timer(eventTime, stimulaListener);
        timerStimula.setRepeats(true);
        timerStimula.setActionCommand("stimulation");

        cyberListener = new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                //  textPane.setText("<html> <left> <strong> <font size=6 color=" + stimuliColor[colorIndex] + ">" + new String(eventCount + " :=" + cyberintell.get(new Integer(eventCount))));
                actionList.setSelectedIndex(actionSequence);
                eventCount++;
                colorIndex++;
                fileIndex++;
                //  nextIndex++;

                // anim = false;
                if (eventCount >= groupAnaly.size() + 1) {
                    eventCount = 1;
                }
                if (colorIndex >= 9) {
                    colorIndex = 0;
                }
                if (actionSequence > 8) {
                    actionSequence = 0;
                }
                statusText.setText(statusText.getText() + "\nTimer Sequence=" + sequence + " Action Sequence=" + actionSequence);
                statusText.setText(statusText.getText() + "\nColor Indexing=" + colorIndex + "|| Event Count=" + eventCount);

            }
        };

        timerCyber = new Timer(cyberTime, cyberListener);
        timerCyber.setRepeats(true);
        timerCyber.setActionCommand("cyberAction");

        listener = new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                ses = groupDesc.getAnimation();
                lastIndex = ses.size();

                String frames = ses.get(sequence);
                String[] frame = frames.split(",");

                if (frameCount < frame.length) {
                   // ImageIcon icon = new ImageIcon(this.getClass().getResource("/jcybercat/resources/catre" + frame[frameCount] + ".png"));
                  //  Image img = icon.getImage().getScaledInstance(catImageLabel.getWidth(), catImageLabel.getHeight(), Image.SCALE_SMOOTH);
                  //  icon.setImage(img);
                  //  catImageLabel.setIcon(icon);
                }
                // scrollPane.setViewportView(null);
                // scrollPane.setViewportView(catImageLabel);
                scrollPane.revalidate();
                frameCount++;
                fileIndex++;
                statusText.setText(statusText.getText() + "\nColor Indexing=" + colorIndex + "|| Event Count=" + eventCount);

            }
        };
        timer = new Timer(sleepTime, listener);
        timer.setActionCommand("Animate");
        timer.setRepeats(true);
    // readStimulations();
    }

    private void readStimulations() {

try {

    BufferedReader br = new BufferedReader(new FileReader("groupessay.txt"));
    String dat;
    int c = 0;

    while ((dat = br.readLine()) != null) {
        stimulaVect.add(new String(dat));
        groupAnaly.put(c, new String(dat));
        c++;
    }
    stimulusList.setListData(stimulaVect);
    localStrList = stimulaVect.subList(localStart, localEnd);
    localList.setListData(localStrList.toArray());
    sociaList = stimulaVect.subList(socioStart, socioEnd);
    socialList.setListData(sociaList.toArray());
    areList = stimulaVect.subList(areaStart, areaEnd);
    areaList.setListData(areList.toArray());
    cuntryList = stimulaVect.subList(coutryStart, countryEnd);
    countryList.setListData(cuntryList.toArray());
    grpList = stimulaVect.subList(grpStart, grpEnd);
    groupList.setListData(grpList.toArray());
    peoList = stimulaVect.subList(peoStart, peoEnd);
    peopleList.setListData(peoList.toArray());
    thiList = stimulaVect.subList(thiStart, thinEnd);
    thingList.setListData(thiList.toArray());

    statusText.setText(statusText.getText() + "\nArea data is listed..");
    statusText.setText(statusText.getText() + "\nCountry data is listed..");
    statusText.setText(statusText.getText() + "\nSocial data is listed...");
    statusText.setText(statusText.getText() + "\nLocal data is listed....");
    statusText.setText(statusText.getText() + "\nPeople data is listed.....");
    statusText.setText(statusText.getText() + "\nThing data is listed.......");
    statusText.setText(statusText.getText() + "\nIntelligece data is listed.......");
    statusText.setText(statusText.getText() + "\nDescribing simulation data as group analysis.");
    groupDesc.getStimulation().put(new Integer(9), groupAnaly);
} catch (IOException ex) {
            Logger.getLogger(JSocioAreaCountryGRpView.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Action
    public void showAboutBox() {
        if (aboutBox == null) {
            JFrame mainFrame = JSocioAreaCountGrpApp.getApplication().getMainFrame();
            aboutBox = new JSocioAreaCountryGrpAboutView(mainFrame);
            aboutBox.setLocationRelativeTo(mainFrame);
        }
        JSocioAreaCountGrpApp.getApplication().show(aboutBox);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        scrollPane = new javax.swing.JScrollPane();
        catImageLabel = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        textPane = new javax.swing.JTextPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        actionList = new javax.swing.JList();
        smallPreviewLabel = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        statusText = new javax.swing.JTextPane();
        jScrollPane5 = new javax.swing.JScrollPane();
        stimulusList = new javax.swing.JList();
        jScrollPane7 = new javax.swing.JScrollPane();
        socialList = new javax.swing.JList();
        jScrollPane8 = new javax.swing.JScrollPane();
        areaList = new javax.swing.JList();
        jScrollPane9 = new javax.swing.JScrollPane();
        countryList = new javax.swing.JList();
        jScrollPane11 = new javax.swing.JScrollPane();
        peopleList = new javax.swing.JList();
        jScrollPane12 = new javax.swing.JScrollPane();
        thingList = new javax.swing.JList();
        jScrollPane13 = new javax.swing.JScrollPane();
        localList = new javax.swing.JList();
        jScrollPane10 = new javax.swing.JScrollPane();
        groupList = new javax.swing.JList();
        jScrollPane4 = new javax.swing.JScrollPane();
        predicateView = new javax.swing.JEditorPane();
        jScrollPane6 = new javax.swing.JScrollPane();
        stimulusView = new javax.swing.JTextPane();
        smallPreviewLabel1 = new javax.swing.JLabel();
        menuBar = new javax.swing.JMenuBar();
        javax.swing.JMenu fileMenu = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        runCyberMI = new javax.swing.JMenuItem();
        animateItem = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();
        javax.swing.JMenuItem exitMenuItem = new javax.swing.JMenuItem();
        javax.swing.JMenu helpMenu = new javax.swing.JMenu();
        javax.swing.JMenuItem aboutMenuItem = new javax.swing.JMenuItem();
        statusPanel = new javax.swing.JPanel();
        javax.swing.JSeparator statusPanelSeparator = new javax.swing.JSeparator();
        statusMessageLabel = new javax.swing.JLabel();
        statusAnimationLabel = new javax.swing.JLabel();
        progressBar = new javax.swing.JProgressBar();
        nextBtn = new javax.swing.JButton();
        prevBtn = new javax.swing.JButton();
        LastBtn = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        analysisView = new javax.swing.JTextPane();

        org.jdesktop.application.ResourceMap resourceMap = org.jdesktop.application.Application.getInstance(coglang.JSocioAreaCountGrpApp.class).getContext().getResourceMap(JSocioAreaCountryGRpView.class);
        mainPanel.setBackground(resourceMap.getColor("mainPanel.background")); // NOI18N
        mainPanel.setName("mainPanel"); // NOI18N

        scrollPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        scrollPane.setAutoscrolls(true);
        scrollPane.setName("scrollPane"); // NOI18N

        catImageLabel.setBackground(resourceMap.getColor("catImageLabel.background")); // NOI18N
        catImageLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        catImageLabel.setIcon(resourceMap.getIcon("catImageLabel.icon")); // NOI18N
        catImageLabel.setText(resourceMap.getString("catImageLabel.text")); // NOI18N
        catImageLabel.setToolTipText(resourceMap.getString("catImageLabel.toolTipText")); // NOI18N
        catImageLabel.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        catImageLabel.setName("catImageLabel"); // NOI18N
        catImageLabel.setPreferredSize(new java.awt.Dimension(250, 400));
        scrollPane.setViewportView(catImageLabel);

        jScrollPane2.setName("jScrollPane2"); // NOI18N

        textPane.setBackground(resourceMap.getColor("textPane.background")); // NOI18N
        textPane.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 4, true));
        textPane.setContentType(resourceMap.getString("textPane.contentType")); // NOI18N
        textPane.setFont(resourceMap.getFont("textPane.font")); // NOI18N
        textPane.setText(resourceMap.getString("textPane.text")); // NOI18N
        textPane.setToolTipText(resourceMap.getString("textPane.toolTipText")); // NOI18N
        textPane.setName("textPane"); // NOI18N
        jScrollPane2.setViewportView(textPane);

        jPanel1.setName("jPanel1"); // NOI18N

        jScrollPane3.setName("jScrollPane3"); // NOI18N

        actionList.setBackground(resourceMap.getColor("actionList.background")); // NOI18N
        actionList.setFont(resourceMap.getFont("actionList.font")); // NOI18N
        actionList.setForeground(resourceMap.getColor("actionList.foreground")); // NOI18N
        actionList.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Social Group", "Area Group", "Country Group", "People Group", "Thing Group", "Local Group", "Group Analysis", "Random Group", "SAC Group" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        actionList.setName("actionList"); // NOI18N
        actionList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                actionListValueChanged(evt);
            }
        });
        jScrollPane3.setViewportView(actionList);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        smallPreviewLabel.setForeground(resourceMap.getColor("smallPreviewLabel.foreground")); // NOI18N
        smallPreviewLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        smallPreviewLabel.setIcon(resourceMap.getIcon("smallPreviewLabel.icon")); // NOI18N
        smallPreviewLabel.setText(resourceMap.getString("smallPreviewLabel.text")); // NOI18N
        smallPreviewLabel.setToolTipText(resourceMap.getString("smallPreviewLabel.toolTipText")); // NOI18N
        smallPreviewLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        smallPreviewLabel.setName("smallPreviewLabel"); // NOI18N
        smallPreviewLabel.setPreferredSize(new java.awt.Dimension(134, 80));

        jTabbedPane1.setBackground(resourceMap.getColor("jTabbedPane1.background")); // NOI18N
        jTabbedPane1.setForeground(resourceMap.getColor("jTabbedPane1.foreground")); // NOI18N
        jTabbedPane1.setTabPlacement(javax.swing.JTabbedPane.BOTTOM);
        jTabbedPane1.setToolTipText(resourceMap.getString("jTabbedPane1.toolTipText")); // NOI18N
        jTabbedPane1.setFont(resourceMap.getFont("jTabbedPane1.font")); // NOI18N
        jTabbedPane1.setName("jTabbedPane1"); // NOI18N

        jScrollPane1.setName("jScrollPane1"); // NOI18N

        statusText.setBackground(resourceMap.getColor("statusText.background")); // NOI18N
        statusText.setText(resourceMap.getString("statusText.text")); // NOI18N
        statusText.setName("statusText"); // NOI18N
        jScrollPane1.setViewportView(statusText);

        jTabbedPane1.addTab(resourceMap.getString("jScrollPane1.TabConstraints.tabTitle"), jScrollPane1); // NOI18N

        jScrollPane5.setName("jScrollPane5"); // NOI18N

        stimulusList.setBackground(resourceMap.getColor("stimulusList.background")); // NOI18N
        stimulusList.setForeground(resourceMap.getColor("stimulusList.foreground")); // NOI18N
        stimulusList.setName("stimulusList"); // NOI18N
        stimulusList.setSelectionBackground(resourceMap.getColor("stimulusList.selectionBackground")); // NOI18N
        stimulusList.setSelectionForeground(resourceMap.getColor("stimulusList.selectionForeground")); // NOI18N
        jScrollPane5.setViewportView(stimulusList);

        jTabbedPane1.addTab(resourceMap.getString("jScrollPane5.TabConstraints.tabTitle"), jScrollPane5); // NOI18N

        jScrollPane7.setName("jScrollPane7"); // NOI18N

        socialList.setBackground(resourceMap.getColor("socialList.background")); // NOI18N
        socialList.setName("socialList"); // NOI18N
        socialList.setSelectionBackground(resourceMap.getColor("socialList.selectionBackground")); // NOI18N
        socialList.setSelectionForeground(resourceMap.getColor("socialList.selectionForeground")); // NOI18N
        jScrollPane7.setViewportView(socialList);

        jTabbedPane1.addTab(resourceMap.getString("jScrollPane7.TabConstraints.tabTitle"), jScrollPane7); // NOI18N

        jScrollPane8.setName("jScrollPane8"); // NOI18N

        areaList.setBackground(resourceMap.getColor("areaList.background")); // NOI18N
        areaList.setName("areaList"); // NOI18N
        areaList.setSelectionBackground(resourceMap.getColor("areaList.selectionBackground")); // NOI18N
        areaList.setSelectionForeground(resourceMap.getColor("areaList.selectionForeground")); // NOI18N
        jScrollPane8.setViewportView(areaList);

        jTabbedPane1.addTab(resourceMap.getString("jScrollPane8.TabConstraints.tabTitle"), jScrollPane8); // NOI18N

        jScrollPane9.setName("jScrollPane9"); // NOI18N

        countryList.setBackground(resourceMap.getColor("countryList.background")); // NOI18N
        countryList.setName("countryList"); // NOI18N
        countryList.setSelectionBackground(resourceMap.getColor("countryList.selectionBackground")); // NOI18N
        countryList.setSelectionForeground(resourceMap.getColor("countryList.selectionForeground")); // NOI18N
        jScrollPane9.setViewportView(countryList);

        jTabbedPane1.addTab(resourceMap.getString("jScrollPane9.TabConstraints.tabTitle"), jScrollPane9); // NOI18N

        jScrollPane11.setName("jScrollPane11"); // NOI18N

        peopleList.setBackground(resourceMap.getColor("peopleList.background")); // NOI18N
        peopleList.setName("peopleList"); // NOI18N
        peopleList.setSelectionBackground(resourceMap.getColor("peopleList.selectionBackground")); // NOI18N
        peopleList.setSelectionForeground(resourceMap.getColor("peopleList.selectionForeground")); // NOI18N
        jScrollPane11.setViewportView(peopleList);

        jTabbedPane1.addTab(resourceMap.getString("jScrollPane11.TabConstraints.tabTitle"), jScrollPane11); // NOI18N

        jScrollPane12.setName("jScrollPane12"); // NOI18N

        thingList.setBackground(resourceMap.getColor("thingList.background")); // NOI18N
        thingList.setName("thingList"); // NOI18N
        thingList.setSelectionBackground(resourceMap.getColor("thingList.selectionBackground")); // NOI18N
        thingList.setSelectionForeground(resourceMap.getColor("thingList.selectionForeground")); // NOI18N
        jScrollPane12.setViewportView(thingList);

        jTabbedPane1.addTab(resourceMap.getString("jScrollPane12.TabConstraints.tabTitle"), jScrollPane12); // NOI18N

        jScrollPane13.setName("jScrollPane13"); // NOI18N

        localList.setBackground(resourceMap.getColor("localList.background")); // NOI18N
        localList.setName("localList"); // NOI18N
        localList.setSelectionBackground(resourceMap.getColor("localList.selectionBackground")); // NOI18N
        localList.setSelectionForeground(resourceMap.getColor("localList.selectionForeground")); // NOI18N
        jScrollPane13.setViewportView(localList);

        jTabbedPane1.addTab(resourceMap.getString("jScrollPane13.TabConstraints.tabTitle"), jScrollPane13); // NOI18N

        jScrollPane10.setName("jScrollPane10"); // NOI18N

        groupList.setBackground(resourceMap.getColor("groupList.background")); // NOI18N
        groupList.setName("groupList"); // NOI18N
        groupList.setSelectionBackground(resourceMap.getColor("groupList.selectionBackground")); // NOI18N
        groupList.setSelectionForeground(resourceMap.getColor("groupList.selectionForeground")); // NOI18N
        jScrollPane10.setViewportView(groupList);

        jTabbedPane1.addTab(resourceMap.getString("jScrollPane10.TabConstraints.tabTitle"), jScrollPane10); // NOI18N

        jScrollPane4.setName("jScrollPane4"); // NOI18N

        predicateView.setBackground(resourceMap.getColor("predicateView.background")); // NOI18N
        predicateView.setBorder(new javax.swing.border.LineBorder(resourceMap.getColor("predicateView.border.lineColor"), 4, true)); // NOI18N
        predicateView.setContentType(resourceMap.getString("predicateView.contentType")); // NOI18N
        predicateView.setFont(resourceMap.getFont("predicateView.font")); // NOI18N
        predicateView.setForeground(resourceMap.getColor("predicateView.foreground")); // NOI18N
        predicateView.setName("predicateView"); // NOI18N
        jScrollPane4.setViewportView(predicateView);

        jScrollPane6.setName("jScrollPane6"); // NOI18N

        stimulusView.setBackground(resourceMap.getColor("stimulusView.background")); // NOI18N
        stimulusView.setBorder(new javax.swing.border.LineBorder(resourceMap.getColor("stimulusView.border.lineColor"), 4, true)); // NOI18N
        stimulusView.setContentType(resourceMap.getString("stimulusView.contentType")); // NOI18N
        stimulusView.setName("stimulusView"); // NOI18N
        jScrollPane6.setViewportView(stimulusView);

        smallPreviewLabel1.setForeground(resourceMap.getColor("smallPreviewLabel1.foreground")); // NOI18N
        smallPreviewLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        smallPreviewLabel1.setIcon(resourceMap.getIcon("smallPreviewLabel1.icon")); // NOI18N
        smallPreviewLabel1.setToolTipText(resourceMap.getString("smallPreviewLabel1.toolTipText")); // NOI18N
        smallPreviewLabel1.setName("smallPreviewLabel1"); // NOI18N
        smallPreviewLabel1.setPreferredSize(new java.awt.Dimension(134, 80));

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, mainPanelLayout.createSequentialGroup()
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(smallPreviewLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(smallPreviewLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(jScrollPane4)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 605, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(scrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 299, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(13, Short.MAX_VALUE))
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTabbedPane1, 0, 0, Short.MAX_VALUE)
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addComponent(smallPreviewLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(smallPreviewLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 59, Short.MAX_VALUE))
                    .addComponent(scrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 242, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE))
                .addContainerGap())
        );

        menuBar.setBackground(resourceMap.getColor("menuBar.background")); // NOI18N
        menuBar.setForeground(resourceMap.getColor("menuBar.foreground")); // NOI18N
        menuBar.setName("menuBar"); // NOI18N

        fileMenu.setText(resourceMap.getString("fileMenu.text")); // NOI18N
        fileMenu.setFont(resourceMap.getFont("fileMenu.font")); // NOI18N
        fileMenu.setName("fileMenu"); // NOI18N
        fileMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fileMenuActionPerformed(evt);
            }
        });

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_T, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem2.setFont(resourceMap.getFont("jMenuItem2.font")); // NOI18N
        jMenuItem2.setText(resourceMap.getString("jMenuItem2.text")); // NOI18N
        jMenuItem2.setName("jMenuItem2"); // NOI18N
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        fileMenu.add(jMenuItem2);

        runCyberMI.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.CTRL_MASK));
        runCyberMI.setFont(resourceMap.getFont("runCyberMI.font")); // NOI18N
        runCyberMI.setText(resourceMap.getString("runCyberMI.text")); // NOI18N
        runCyberMI.setName("runCyberMI"); // NOI18N
        runCyberMI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                runCyberMIActionPerformed(evt);
            }
        });
        fileMenu.add(runCyberMI);

        animateItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.SHIFT_MASK));
        animateItem.setFont(resourceMap.getFont("animateItem.font")); // NOI18N
        animateItem.setText(resourceMap.getString("animateItem.text")); // NOI18N
        animateItem.setName("animateItem"); // NOI18N
        animateItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                animateItemActionPerformed(evt);
            }
        });
        animateItem.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                animateItemAncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        fileMenu.add(animateItem);

        jMenuItem3.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem3.setFont(resourceMap.getFont("jMenuItem3.font")); // NOI18N
        jMenuItem3.setText(resourceMap.getString("jMenuItem3.text")); // NOI18N
        jMenuItem3.setName("jMenuItem3"); // NOI18N
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        fileMenu.add(jMenuItem3);

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.ALT_MASK));
        jMenuItem1.setFont(resourceMap.getFont("jMenuItem1.font")); // NOI18N
        jMenuItem1.setText(resourceMap.getString("jMenuItem1.text")); // NOI18N
        jMenuItem1.setName("jMenuItem1"); // NOI18N
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        fileMenu.add(jMenuItem1);

        javax.swing.ActionMap actionMap = org.jdesktop.application.Application.getInstance(coglang.JSocioAreaCountGrpApp.class).getContext().getActionMap(JSocioAreaCountryGRpView.class, this);
        exitMenuItem.setAction(actionMap.get("quit")); // NOI18N
        exitMenuItem.setForeground(resourceMap.getColor("exitMenuItem.foreground")); // NOI18N
        exitMenuItem.setName("exitMenuItem"); // NOI18N
        fileMenu.add(exitMenuItem);

        menuBar.add(fileMenu);

        helpMenu.setText(resourceMap.getString("helpMenu.text")); // NOI18N
        helpMenu.setFont(resourceMap.getFont("helpMenu.font")); // NOI18N
        helpMenu.setName("helpMenu"); // NOI18N

        aboutMenuItem.setAction(actionMap.get("showAboutBox")); // NOI18N
        aboutMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_MASK));
        aboutMenuItem.setFont(resourceMap.getFont("aboutMenuItem.font")); // NOI18N
        aboutMenuItem.setName("aboutMenuItem"); // NOI18N
        helpMenu.add(aboutMenuItem);

        menuBar.add(helpMenu);

        statusPanel.setBackground(resourceMap.getColor("statusPanel.background")); // NOI18N
        statusPanel.setName("statusPanel"); // NOI18N

        statusPanelSeparator.setName("statusPanelSeparator"); // NOI18N

        statusMessageLabel.setName("statusMessageLabel"); // NOI18N

        statusAnimationLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        statusAnimationLabel.setName("statusAnimationLabel"); // NOI18N

        progressBar.setName("progressBar"); // NOI18N

        nextBtn.setBackground(resourceMap.getColor("nextBtn.background")); // NOI18N
        nextBtn.setText(resourceMap.getString("nextBtn.text")); // NOI18N
        nextBtn.setName("nextBtn"); // NOI18N
        nextBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextBtnActionPerformed(evt);
            }
        });

        prevBtn.setBackground(resourceMap.getColor("prevBtn.background")); // NOI18N
        prevBtn.setText(resourceMap.getString("prevBtn.text")); // NOI18N
        prevBtn.setName("prevBtn"); // NOI18N
        prevBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prevBtnActionPerformed(evt);
            }
        });

        LastBtn.setBackground(resourceMap.getColor("LastBtn.background")); // NOI18N
        LastBtn.setText(resourceMap.getString("LastBtn.text")); // NOI18N
        LastBtn.setName("LastBtn"); // NOI18N
        LastBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LastBtnActionPerformed(evt);
            }
        });

        jLabel1.setFont(resourceMap.getFont("jLabel1.font")); // NOI18N
        jLabel1.setForeground(resourceMap.getColor("jLabel1.foreground")); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel1.setIcon(resourceMap.getIcon("jLabel1.icon")); // NOI18N
        jLabel1.setText(resourceMap.getString("jLabel1.text")); // NOI18N
        jLabel1.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel1.setName("jLabel1"); // NOI18N

        analysisView.setBackground(resourceMap.getColor("analysisView.background")); // NOI18N
        analysisView.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(153, 0, 51), 4, true));
        analysisView.setContentType(resourceMap.getString("analysisView.contentType")); // NOI18N
        analysisView.setToolTipText(resourceMap.getString("analysisView.toolTipText")); // NOI18N
        analysisView.setName("analysisView"); // NOI18N

        javax.swing.GroupLayout statusPanelLayout = new javax.swing.GroupLayout(statusPanel);
        statusPanel.setLayout(statusPanelLayout);
        statusPanelLayout.setHorizontalGroup(
            statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(statusPanelLayout.createSequentialGroup()
                .addGroup(statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(statusPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(statusMessageLabel))
                    .addGroup(statusPanelLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(nextBtn))
                    .addGroup(statusPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(statusPanelLayout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(LastBtn))
                            .addComponent(prevBtn))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(analysisView, javax.swing.GroupLayout.PREFERRED_SIZE, 614, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(statusPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, statusPanelLayout.createSequentialGroup()
                                .addGap(298, 298, 298)
                                .addComponent(statusPanelSeparator, javax.swing.GroupLayout.DEFAULT_SIZE, 1, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, statusPanelLayout.createSequentialGroup()
                                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap())
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, statusPanelLayout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addContainerGap())))
                    .addGroup(statusPanelLayout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(statusAnimationLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        statusPanelLayout.setVerticalGroup(
            statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(statusPanelLayout.createSequentialGroup()
                .addGroup(statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(statusPanelLayout.createSequentialGroup()
                        .addComponent(statusPanelSeparator, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(8, 8, 8)
                        .addGroup(statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(statusPanelLayout.createSequentialGroup()
                                .addComponent(nextBtn)
                                .addGap(19, 19, 19))
                            .addGroup(statusPanelLayout.createSequentialGroup()
                                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(33, 33, 33)
                                .addComponent(statusAnimationLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(5, 5, 5)))
                        .addGroup(statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(statusPanelLayout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(prevBtn)
                                .addGroup(statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, statusPanelLayout.createSequentialGroup()
                                        .addComponent(statusMessageLabel)
                                        .addGap(73, 73, 73))
                                    .addGroup(statusPanelLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(LastBtn)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))))
                            .addGroup(statusPanelLayout.createSequentialGroup()
                                .addGap(31, 31, 31)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(analysisView, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        setComponent(mainPanel);
        setMenuBar(menuBar);
        setStatusBar(statusPanel);
    }// </editor-fold>//GEN-END:initComponents
    private void actionListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_actionListValueChanged

        int index = actionList.getSelectedIndex();
        actionIndex = index + 1;
        nextIndex = 1;
        String[] stimuliColor = {"#FBCBEB", "#345577", "black", "orange", "#23CCBE", "#9BFFE", "#77CFBF", "#00BCFF", "white"};

        //   if (anim) {

        //    } else if (!anim) {
        switch (actionIndex) {
            case 1://social
                ses = groupDesc.getSocialGroup();
                textPane.setToolTipText("Social Group");
                statusText.setText(statusText.getText() +"Selection in Social Group");
                statusText.setText(statusText.getText() + "\nSelection in Social Group");

                predicateView.setText("<html> <center> <strong> <font size=7 color=" + stimuliColor[colorIndex] + ">" + new String(ses.get(new Integer(nextIndex))));
                nextIndex++;
                lastIndex = ses.size();
                break;
            case 2://area

                ses = groupDesc.getAreaGroup();
                textPane.setToolTipText("Area Group");
                statusText.setText(statusText.getText() +"Selection in Area Group");
                statusText.setText(statusText.getText() + "\nSelection in Area Group");

                predicateView.setText("<html> <center> <strong> <font size=8 color=" + stimuliColor[colorIndex] + ">" + new String(ses.get(new Integer(nextIndex))));
                nextIndex++;
                lastIndex = ses.size();
                break;
            case 3://country
                ses = groupDesc.getCountryGroup();
                textPane.setToolTipText("Country Group");
                statusText.setText(statusText.getText() +"Selection in Country Group");
                statusText.setText(statusText.getText() + "\nSelection in Country Group");

                predicateView.setText("<html> <center> <strong> <font size=7 color=" + stimuliColor[colorIndex] + ">" + new String(ses.get(new Integer(nextIndex))));
                nextIndex++;
                lastIndex = ses.size();
                break;
            case 4://people
                ses = groupDesc.getPeopleGroup();
                textPane.setToolTipText("People Group");
                statusText.setText(statusText.getText() +"Selection in People Group");
                statusText.setText(statusText.getText() + "\nSelection in People Group");

                predicateView.setText("<html> <center> <strong> <font size=8 color" + stimuliColor[colorIndex] + ">" + new String(ses.get(new Integer(nextIndex))));
                nextIndex++;
                lastIndex = ses.size();
                break;
            case 5://thing
                ses = groupDesc.getThingGroup();
                textPane.setToolTipText("Thing Group");
                statusText.setText(statusText.getText() +"Selection in Thing Group");
                statusText.setText(statusText.getText() + "\nSelection in Thing Group");

                predicateView.setText("<html> <center> <strong> <font size=8 color=" + stimuliColor[colorIndex] + ">" + new String(ses.get(new Integer(nextIndex))));
                nextIndex++;
                lastIndex = ses.size();
                break;
            case 6://local
                ses = groupDesc.getLocalGroup();
                textPane.setToolTipText("Local Group");
                statusText.setText(statusText.getText() +"Selection in Local Group");
                predicateView.setText("<html> <center> <strong> <font size=7 color=" + stimuliColor[colorIndex] + ">" + new String(ses.get(new Integer(nextIndex))));
                statusText.setText(statusText.getText() + "\nSelection in Local Group");

                nextIndex++;
                lastIndex = ses.size();
                break;
            case 7://group analysis
                ses = groupDesc.getGroupAnalysis();
                textPane.setToolTipText("Group Analysis");
                statusText.setText(statusText.getText() +"Selection in Group Analysis");
                predicateView.setText("<html> <center> <strong> <font size=8 color=" + stimuliColor[colorIndex] + ">" + new String(ses.get(new Integer(nextIndex))));
                statusText.setText(statusText.getText() + "\nSelection in Group Analysis");

                nextIndex++;
                lastIndex = ses.size();
                break;
            case 8://random group
                ses = groupDesc.getRandomGroup();
                textPane.setToolTipText("Random Group");
                statusText.setText(statusText.getText() +"Selection in Random Group");
                predicateView.setText("<html> <center> <strong> <font size=8 color=" + stimuliColor[colorIndex] + ">" + new String(ses.get(new Integer(nextIndex))));
                statusText.setText(statusText.getText() + "\nSelection in Random Group.");
                nextIndex++;
                lastIndex = ses.size();
                break;
            case 9://SAC group
                ses = groupDesc.getRandomGroup();
                textPane.setToolTipText("SAC Group");
                statusText.setText(statusText.getText() +"Selection in SAC Group");
                predicateView.setText("<html> <center> <strong> <font size=8 color=" + stimuliColor[colorIndex] + ">" + new String(ses.get(new Integer(nextIndex))));
                statusText.setText(statusText.getText() + "\nSelection in SAC Group.");

                nextIndex++;
                lastIndex = ses.size();
                break;
            case 10://Animation
                break;
            case 11://Stimulation
                break;
            case 12:
                break;
            }

        if (colorIndex > 8) {
            colorIndex = 0;
        }
    //   }
}//GEN-LAST:event_actionListValueChanged

    private void nextBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextBtnActionPerformed

      //  ImageIcon icon = new ImageIcon(this.getClass().getResource("/jcybercat/resources/catre" + nextIndex + ".png"));
      //  Image img = icon.getImage().getScaledInstance(catImageLabel.getWidth(), catImageLabel.getHeight(), Image.SCALE_SMOOTH);
      //  icon.setImage(img);
      //  catImageLabel.setIcon(icon);
        colorIndex++;

//         ImageIcon icon1=icon;
//         img=icon1.getImage().getScaledInstance(smallPreviewLabel.getWidth(), smallPreviewLabel.getHeight(), Image.SCALE_SMOOTH);
//         icon1.setImage(img);
//         smallPreviewLabel.setIcon(icon1);

        switch (actionIndex) {
            case 1://social
                textPane.setText("<html> <center> <strong> <font size=12 color=blue>" + new String(nextIndex + " " + ses.get(new Integer(nextIndex))));

                if (nextIndex > ses.size()) {
                    textPane.setText("Social groups are finish.");
                    nextIndex = 1;
                }
                nextIndex++;
                break;
            case 2://area
                textPane.setText("<html> <center> <strong> <font size=11 color=green>" + new String(nextIndex + " " + ses.get(new Integer(nextIndex))));
                if (nextIndex > ses.size()) {
                    textPane.setText("Area groupings are finish.");
                    nextIndex = 1;
                }
                nextIndex++;
                break;
            case 3://country
                textPane.setText("<html> <center> <strong> <font size=12 color=yellow>" + new String(nextIndex + " " + ses.get(new Integer(nextIndex))));
                nextIndex++;
                if (nextIndex > ses.size()) {
                    textPane.setText("Country groups are finish.");
                    nextIndex = 1;
                }
                break;
            case 4://people
                textPane.setText("<html> <center> <strong> <font size=10 color=red>" + new String(nextIndex + " " + ses.get(new Integer(nextIndex))));
                nextIndex++;
                if (nextIndex > ses.size()) {
                    textPane.setText("People groupings are finish.");
                    nextIndex = 1;
                }
                break;
            case 5://thing
                textPane.setText("<html> <center> <strong> <font size=10 color=#2CDDF>" + new String(nextIndex + " " + ses.get(new Integer(nextIndex))));
                nextIndex++;
                if (nextIndex > ses.size()) {
                    textPane.setText("Thing groups are finish.");
                    nextIndex = 1;
                }
                break;
            case 6://local
                textPane.setText("<html> <center> <strong> <font size=11 color=#6EDCF>" + new String(nextIndex + " " + ses.get(new Integer(nextIndex))));
                nextIndex++;
                if (nextIndex > ses.size()) {
                    textPane.setText("Local groupings are finish.");
                    nextIndex = 1;
                }
                break;
            case 7://group anal
                textPane.setText("<html> <center> <strong> <font size=12 color=#9EECF>" + new String(nextIndex + " " + ses.get(new Integer(nextIndex))));
                nextIndex++;
                if (nextIndex > ses.size()) {
                    textPane.setText("Group analyzes are finish.");
                    nextIndex = 1;
                }
                break;
            case 8://random
                textPane.setText("<html> <center> <strong> <font size=10 color=#8DDCF>" + new String(nextIndex + " " + ses.get(new Integer(nextIndex))));
                nextIndex++;
                if (nextIndex > ses.size()) {
                    textPane.setText("Random groups are finish.");
                    nextIndex = 1;
                }
                break;
            case 9://sac group
                textPane.setText("<html> <center> <strong> <font size=11 color=#8DDFF>" + new String(nextIndex + " " + ses.get(new Integer(nextIndex))));
                nextIndex++;
                if (nextIndex > ses.size()) {
                    textPane.setText("SAC Groups are finish.");
                    nextIndex = 1;
                }
                break;
           
        }
    }//GEN-LAST:event_nextBtnActionPerformed

    private void prevBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prevBtnActionPerformed

        nextIndex--;
        textPane.setText("<html> <center> <strong> <font size=10 color=lightyellow>" + new String(nextIndex + " " + ses.get(new Integer(nextIndex))));
        if (nextIndex < 1) {
            nextIndex = 1;
        } 
            
    }//GEN-LAST:event_prevBtnActionPerformed

    private void LastBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LastBtnActionPerformed

        nextIndex = ses.size();
        textPane.setText("<html> <center> <strong> <font size=10 color=yellow>" + new String(nextIndex + " " + ses.get(new Integer(nextIndex))));
          
    }//GEN-LAST:event_LastBtnActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // TODO add your handling code here:
        String sleep = JOptionPane.showInputDialog("Enter the sleep time in-between frames");
        sleepTime = Integer.parseInt(sleep);
        timer.removeActionListener(listener);
        timerStimula.removeActionListener(stimulaListener);

        timer = new Timer(sleepTime, listener);
        timer.setInitialDelay(sleepTime);

        timerStimula = new Timer(sleepTime, stimulaListener);
        timerStimula.setInitialDelay(sleepTime);
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void fileMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fileMenuActionPerformed
    // TODO add your handling code here:
    }//GEN-LAST:event_fileMenuActionPerformed

    private void animateItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_animateItemActionPerformed

        timer.removeActionListener(listener);
        timer = new Timer(sleepTime, listener);
        timer.setDelay(sleepTime);
        timer.setInitialDelay(0);
        timer.start();
        if (!timer.isRunning()) {
            timer.restart();
        }
        //  anim = true;
        timerSequence.removeActionListener(timerListener);
        timerSequence = new Timer(sleepTime, timerListener);
        timerSequence.start();
        timerSequence.setInitialDelay(2);
        if (!timerSequence.isRunning()) {
            timerSequence.restart();
        }
        timerStimula.removeActionListener(stimulaListener);
        timerStimula = new Timer(sleepTime, stimulaListener);
        timerStimula.start();
        timerStimula.setInitialDelay(2);
        if (!timerStimula.isRunning()) {
            timerStimula.restart();
        }
        timerStimula.setInitialDelay(1);
        timerStimula.restart();

        statusText.setText(statusText.getText()+"\nAnimation and Simulation Analysis has started:=" + true);
    }//GEN-LAST:event_animateItemActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        timer.stop();
        timerSequence.stop();
        timer.removeActionListener(listener);
        // anim = false;
        timerStimula.stop();
        timerStimula.removeActionListener(stimulaListener);
      //  statusMessageLabel.setText("Animation and Simulation Analysis has started:=" + false);
        statusText.setText(statusText.getText() + "Animation and Simulation Analysis has started:=" + false);
       
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void animateItemAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_animateItemAncestorAdded
    // TODO add your handling code here:
    }//GEN-LAST:event_animateItemAncestorAdded

    private void runCyberMIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_runCyberMIActionPerformed

        if (!anim) {
            timer.removeActionListener(listener);
            timer = new Timer(cyberTime, listener);
            timer.setDelay(cyberTime);
            timer.setInitialDelay(0);
            timer.start();
            if (!timer.isRunning()) {
                timer.restart();
            }
            anim = true;
            timerSequence.removeActionListener(timerListener);
            timerSequence = new Timer(cyberTime, timerListener);
            timerSequence.start();
            timerSequence.setInitialDelay(2);
            if (!timerSequence.isRunning()) {
                timerSequence.restart();
            }
            timerCyber.removeActionListener(cyberListener);
            timerCyber = new Timer(cyberTime, cyberListener);
            timerCyber.start();
            timerCyber.setInitialDelay(2);
            if (!timerCyber.isRunning()) {
                timerCyber.restart();
            }
          //  statusMessageLabel.setText("Running Language Simulation :=" + anim);
            statusText.setText(statusText.getText() + "\nRunning Language Simulation :=" + anim);
        } else {
            timer.stop();
            timerSequence.stop();
            timer.removeActionListener(listener);
            anim = false;
            timerStimula.stop();
            timerStimula.removeActionListener(stimulaListener);
            timerCyber.stop();
            timerCyber.removeActionListener(cyberListener);
          //  statusMessageLabel.setText("Running  Language Simulation :=" + anim);
            statusText.setText(statusText.getText() + "\nRunning  Language Simulation :=" + anim);
        }
        
}//GEN-LAST:event_runCyberMIActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        try {
           BufferedImage bi = new BufferedImage(mainPanel.getWidth(), mainPanel.getHeight(), BufferedImage.TYPE_INT_ARGB_PRE);
           
            Shape p = mainPanel.getGraphics().getClip();

            Robot r = new Robot();
            bi = r.createScreenCapture(new Rectangle(0, 15, mainPanel.getWidth(), mainPanel.getHeight()+10));

            ImageIO.write(bi, "png", new File("screen.png"));
 
        //   mainPanel.print();
        } catch (AWTException ex) {
            Logger.getLogger(JSocioAreaCountryGRpView.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(JSocioAreaCountryGRpView.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton LastBtn;
    private javax.swing.JList actionList;
    private javax.swing.JTextPane analysisView;
    private javax.swing.JMenuItem animateItem;
    private javax.swing.JList areaList;
    private javax.swing.JLabel catImageLabel;
    private javax.swing.JList countryList;
    private javax.swing.JList groupList;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JList localList;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JButton nextBtn;
    private javax.swing.JList peopleList;
    private javax.swing.JEditorPane predicateView;
    private javax.swing.JButton prevBtn;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JMenuItem runCyberMI;
    private javax.swing.JScrollPane scrollPane;
    private javax.swing.JLabel smallPreviewLabel;
    private javax.swing.JLabel smallPreviewLabel1;
    private javax.swing.JList socialList;
    private javax.swing.JLabel statusAnimationLabel;
    private javax.swing.JLabel statusMessageLabel;
    private javax.swing.JPanel statusPanel;
    private javax.swing.JTextPane statusText;
    private javax.swing.JList stimulusList;
    private javax.swing.JTextPane stimulusView;
    private javax.swing.JTextPane textPane;
    private javax.swing.JList thingList;
    // End of variables declaration//GEN-END:variables
    private final Timer messageTimer;
    private final Timer busyIconTimer;
    private final Icon idleIcon;
    private final Icon[] busyIcons = new Icon[15];
    private int busyIconIndex = 0;
    private JDialog aboutBox;
}
