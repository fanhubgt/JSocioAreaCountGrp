java -jar /dist/JSocioAreaCountGrp.jar -splash:splash.png
