/home/appiah/jdk1.6.0_03/bin/java -splash:splash.png -jar dist/JSocioAreaCountGrp.jar
